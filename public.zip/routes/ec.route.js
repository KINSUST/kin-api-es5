const express = require("express");
const { ECFindById, addEc, addMemberInEc, deleteEcById,    getAllEc, memberDataUpdateById, removeEcMemberById, removeMemberById, updateEcById } = require("../controllers/ec.controllers.js");
const { AddECMemberValidator, ECValidator } = require("../middlewares/validator/file/ec.validator.js");
const { isLoggedIn } = require("../middlewares/verify.js");
const { authorization } = require("../middlewares/authorization.js");
const runValidation = require("../middlewares/validator/validation.js");



const ecRouter = express.Router();
 
// routes 
ecRouter.route("/")
  .get( getAllEc)
  .post(
    isLoggedIn,
    authorization("admin", "superAdmin"),
    ECValidator,
    runValidation,
    addEc
  )

  ecRouter.route("/add-member/:id").patch(AddECMemberValidator,runValidation,addMemberInEc);

  ecRouter.route("/update-member/:id").patch(memberDataUpdateById);

  ecRouter.route("/remove-member/:id").patch(removeMemberById);


  ecRouter.route("/:id")
    .get(ECFindById)
    .patch(updateEcById)
    .delete(deleteEcById);



  // // member remove from ec 
  //   ecRouter.route("/:id/:memberId")
  //   .patch(removeEcMemberById)

// export
module.exports = ecRouter;
