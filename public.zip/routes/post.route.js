

const express = require("express");
const { allPost, createPost, findPostById, updatePostById, deletePostBySlug, findPostBySlug } = require("../controllers/post.controllers.js");
const { postMulter } = require("../utils/multer.js");

const postRouter = express.Router();

postRouter.route("/").get(allPost).post(postMulter, createPost);
  
postRouter
  .route("/:id")
  .patch(updatePostById);
 postRouter.route("/:slug").get(findPostBySlug).delete(deletePostBySlug); 

module.exports = postRouter;
