

const express = require("express");
const { allAdvisor, createAdvisor, deleteAdvisorById, findAdvisorById, updateAdvisorById } = require("../controllers/advisor.controllers.js");
const { advisorMulter } = require("../utils/multer.js");
const { isLoggedIn } = require("../middlewares/verify.js");

const advisorRouter = express.Router();
// advisorRouter.use(isLoggedIn)

advisorRouter.route("/").get(allAdvisor).post(advisorMulter,createAdvisor);

advisorRouter
    .route("/:id")
    .get(findAdvisorById)
    .patch(advisorMulter,updateAdvisorById)
    .delete(deleteAdvisorById);
 
// export
module.exports = advisorRouter;