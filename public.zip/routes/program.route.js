

const express = require("express");
const { allProgram, createProgram, deleteProgramById, findProgramById, updateProgramById } = require("../controllers/program.controllers.js");
const { programMulter } = require("../utils/multer.js");

const programRouter = express.Router();

programRouter.route("/").get(allProgram).post(programMulter,createProgram);

programRouter
  .route("/:id")
  .get(findProgramById)
  .patch(programMulter,updateProgramById)
  .delete(deleteProgramById);

// export
module.exports = programRouter;
