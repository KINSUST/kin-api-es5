

const express = require("express");
const { addSubscriber, allSubscriber, deleteSubscriberById, updateSubscriberById } = require("../controllers/subscriber.controllers.js");


const subscriberRouter = express.Router();

subscriberRouter.route("/").get(allSubscriber).post(addSubscriber);

subscriberRouter
  .route("/:id")
  .patch(updateSubscriberById)
  .delete(deleteSubscriberById);

// export
module.exports = subscriberRouter;
