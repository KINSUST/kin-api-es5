

const express = require("express");
const {allNews,createNews,deleteNewsById,findNewsById,} = require("../controllers/news.controllers.js");

const newsRouter = express.Router();

newsRouter.route("/").get(allNews).post(createNews);

newsRouter.route("/:id").get(findNewsById).delete(deleteNewsById);


// export 
module.exports = newsRouter;