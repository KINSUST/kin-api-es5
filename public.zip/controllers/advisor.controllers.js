


const createError = require("http-errors");
const { unlinkSync } = require("fs");
const path = require("path");
const filterQuery = require("../helper/filterQuery.js");
const asyncHandler = require("express-async-handler");
const { successResponse } = require("../services/responseHandler.js");
const checkMongoId = require("../services/checkMongoId.js");
const checkImage = require("../services/imagesCheck.js");
const advisorModel = require("../model/advisor.model.js");
const { log } = require("console");

/**
 * @description get all advisors data
 * @method GET
 * @route  /api/v1/advisors
 * @access public
 */

 const allAdvisor = asyncHandler(async (req, res, next) => {
  const { queries, filters } = filterQuery(req);

  const advisors = await advisorModel
    .find(filters)
    .skip(queries.skip)
    .limit(queries.limit)
    .sort({index:1});

  if (advisors.length < 1) throw createError(400, "Couldn't find any data.");

  // page , total count
  const count = await advisorModel.countDocuments(filters);

  // page & limit
  const page = queries.page;
  const limit = queries.limit;

  // pagination
  // pagination
  const pagination = {
    totalDocuments: count,
    totalPages: Math.ceil(count / limit),
    currentPage: page,
    previousPage: page > 1 ? page - 1 : null,
    nextPage: page < Math.ceil(count / limit) ? page + 1 : null,
  };

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "All advisor data",
    payload: {
      pagination,
      data:advisors,
    },
  });
});
/**
 * @description create advisor data
 * @method POST
 * @route  /api/v1/advisors
 * @access private
 */

 const createAdvisor = asyncHandler(async (req, res) => {
 

 
  // advisor check is already register or not
  const existAdvisor = await advisorModel.exists({
    email: req.body.email,
  });


  // advisor email check
  if (existAdvisor) throw createError(404, "Email already exits!");

  const user = await advisorModel.create({
    ...req.body,
    advisor_photo: req?.file?.filename,
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Advisor data created successfully",
    payload: {
      data:user,
    },
  });
});

/**
 * @description get single advisor data
 * @method GET
 * @route  /api/v1/advisors/:id
 * @access private
 */

 const findAdvisorById = asyncHandler(async (req, res, next) => {
  // id check
  checkMongoId(req.params.id);

  // find advisor
  const advisor = await advisorModel.findById(req.params.id);
  if (!advisor) throw customError(400, "Couldn't find any advisor data.");

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Advisor data",
    payload: {
      data:advisor,
    },
  });
});

/**
 * @description delete single advisor data
 * @method DELETE
 * @route  /api/v1/advisors/:id
 * @access private
 */

 const deleteAdvisorById = asyncHandler(async (req, res, next) => {
  // id check
  checkMongoId(req.params.id);

  // advisor check
  const advisor = await advisorModel.findById(req.params.id);
  if (!advisor) throw createError(400, "Couldn't find any advisor data.");

  // data  delete from database
  const result = await advisorModel.findByIdAndDelete(req.params.id);

  // find image in folder & delete
  checkImage("advisors").find(
    (image) => image === advisor?.advisor_photo
  ) &&
    unlinkSync(
      path.resolve(`./public/images/advisors/${advisor?.advisor_photo}`)
    );

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Advisor data deleted successfully",
    payload: {
      data:result,
    },
  });
}); 

/**
 * @description update single user data
 * @method PUT / PATCH
 * @route  /api/v1/users/:id
 * @access private
 */

 const updateAdvisorById = asyncHandler(async (req, res) => {
  checkMongoId(req.params.id);

  // user check
  const advisorData = await advisorModel.findById(req.params.id);

  if (!advisorData) throw createError(400, "Couldn't find any advisor data.");


  const advisor = await advisorModel.findByIdAndUpdate(
    req.params.id,
    {
      $set: {
        ...req.body,
        advisor_photo: req?.file?.filename,
      },
    },
    {
      new: true,
      runValidators: true,
    }
  );
  
  // find image in folder & delete
  checkImage("advisors").find((image) => image === advisorData?.advisor_photo) &&
    unlinkSync(path.resolve(`./public/images/advisors/${advisorData?.advisor_photo}`));

  //response send
  successResponse(res, {
    statusCode: 200,
    message: "Advisor data updated successfully",
    payload: {
      data:advisor,
    },
  });
});



module.exports = {
  allAdvisor,
  createAdvisor,
  findAdvisorById,
  deleteAdvisorById,
  updateAdvisorById,
};