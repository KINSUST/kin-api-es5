
const createError = require("http-errors");
const newsModel = require("../model/news.model.js");
const { successResponse } = require("../services/responseHandler.js");
const asyncHandler = require("express-async-handler");
const checkMongoId = require("../services/checkMongoId.js");


/**
 * @description get all news data
 * @method GET
 * @route  /api/v1/news-ticker
 * @access public
 */

 const allNews = asyncHandler(async (req, res) => {
  const result = await newsModel.find();

  if (result.length < 1) throw createError(400, "No news data has founded");

  //response send
  successResponse(res, {
    statusCode: 200,
    message: "All news data",
    payload: {
      result,
    },
  });
});

/**
 * @description add  news data
 * @method POST
 * @route  /api/v1/news-ticker
 * @access private
 */

 const createNews = asyncHandler(async (req, res, next) => {
  const beforeDataCheck = await newsModel.find();
  if (beforeDataCheck?.length === 1) {
    throw createError(401, "Already has a news.Please delete before news");
  }

  const result = await newsModel.create(req.body);

  // response send
  successResponse(res, {
    statusCode: 201,
    message: "Successfully added a new news.",
    payload: {
      data: result,
    },
  });
});

/**
 * @description get single  news data
 * @method GET
 * @route  /api/v1/news-ticker/:id
 * @access private
 */

 const findNewsById = asyncHandler(async (req, res, next) => {
  // id check
  checkMongoId(req.params.id);

  const result = await newsModel.findById(req.params.id);
  // empty data check
  if (!result) throw createError(400, "Couldn't find any news data.");
  // data send
  successResponse(res, {
    statusCode: 200,
    message: "News data",
    payload: {
      result,
    },
  });
});

/**
 * @description delete single newsTicker data
 * @method DELETE
 * @route  /api/v1/news-ticker/:id
 * @access private
 */

 const deleteNewsById = asyncHandler(async (req, res, next) => {
  // invalid id check
  checkMongoId(req.params.id);

  // data check
  const news = await newsModel.findById(req.params.id);
  if (!news) throw createError(400, "Couldn't find any news data.");

  const result = await newsModel.findByIdAndDelete(req.params.id);

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Successfully deleted",
    payload: {
      result,
    },
  });
});



module.exports = {
  allNews,
  createNews,
  findNewsById,
  deleteNewsById,
};