

const { unlinkSync } = require("fs");
const programModel = require("../model/program.model.js");
const createError = require("http-errors");
const { successResponse } = require("../services/responseHandler.js");
const asyncHandler = require("express-async-handler");
const checkMongoId = require("../services/checkMongoId.js");
const path = require("path");
const checkImage = require("../services/imagesCheck.js");
const filterQuery = require("../helper/filterQuery.js");

/**
 * @desc get all programs data
 * @name GET /api/v1/program
 * @access public
 */

 const allProgram = asyncHandler(async (req, res) => {
  // query filter
  const { queries, filters } = filterQuery(req);

  // find programs
  const programs = await programModel
    .find(filters)
    .sort(queries.sortBy)
    .skip(queries.skip)
    .limit(queries.limit)
    .select(queries.fields);

  // count documents
  const count = await programModel.countDocuments();

  if (!programs.length)
    throw createError(404, "couldn't find any program data.");

  // page & limit
  const page = queries.page;
  const limit = queries.limit;

  // pagination
  const pagination = {
    totalDocuments: count,
    totalPages: Math.ceil(count / limit),
    currentPage: page,
    previousPage: page > 1 ? page - 1 : null,
    nextPage: page < Math.ceil(count / limit) ? page + 1 : null,
  };

  // response
  return successResponse(res, {
    statusCode: 200,
    message: "Programs data fetched successfully",
    payload: {
      pagination,
      data: programs,
    },
  });
});

/**
 * @desc new program add
 * @name GET /api/v1/program
 * @access public
 */

 const createProgram = asyncHandler(async (req, res) => {
  const { title, date, time, venue, fb_url } = req.body;

  if (!title || !date || !time || !venue || !fb_url)
    createError(400, "Please provide all fields");

  const result = await programModel.create({
    ...req.body,
    program_photo: req.file?.filename,
  });

  // response
  successResponse(res, {
    statusCode: 200,
    message: "Successfully added a new program.",
    payload: {
      data: result,
    },
  });
});

/**
 * @desc get program post
 * @name GET /api/v1/program
 * @access public
 */

 const findProgramById = asyncHandler(async (req, res) => {
  checkMongoId(req.params.id);
  const result = await programModel.findById(req.params.id);
  if (!result) throw createError(404, "No data found");

  // response
  successResponse(res, {
    statusCode: 200,
    message: "Program data fetched successfully",
    payload: {
      data: result,
    },
  });
});

/**
 * @desc delete single program
 * @name DELETE /api/v1/program
 * @access public
 */

 const deleteProgramById = asyncHandler(async (req, res) => {
  // check id
  checkMongoId(req.params.id);

  // find data
  const programData = await programModel.findById(req.params.id);
  if (!programData) throw createError(404, "No data found");

  // delete data
  const result = await programModel.findByIdAndDelete(req.params.id);

  // find image in folder & delete
  checkImage("programs").find(
    (image) => image === programData?.program_photo
  ) &&
    unlinkSync(
      path.resolve(`./public/images/programs/${programData?.program_photo}`)
    );

  // response
  successResponse(res, {
    statusCode: 200,
    message: "Program data deleted successfully",
    payload: {
      data: result,
    },
  });
});

/**
 * @desc update single program
 * @name PATCH /api/v1/program
 * @access public
 */

 const updateProgramById = asyncHandler(async (req, res) => {
  // check id
  checkMongoId(req.params.id);
  console.log(req.file);

  // find data
  const programData = await programModel.findById(req.params.id);
  if (!programData) throw createError(404, "No data found");

  // update options
  const options = {
    $set: {
      ...req.body,
      program_photo: req.file?.filename,
    },
  };

  // update data
  const result = await programModel.findByIdAndUpdate(req.params.id, options, {
    new: true,
    runValidators: true,
  });

  // find image in folder & delete
  req.file && checkImage("programs").find((image) => image === programData?.program_photo) &&
    unlinkSync(path.resolve(`./public/images/programs/${programData?.program_photo}`));

  // response
  successResponse(res, {
    statusCode: 200,
    message: "Program data updated successfully",
    payload: {
      data: result,
    },
  });
});



module.exports = {
  allProgram,
  createProgram,
  findProgramById,
  deleteProgramById,
  updateProgramById,
};