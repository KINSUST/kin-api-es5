

const createError = require("http-errors");
const subscriberModel = require("../model/subscriber.model.js");
const filterQuery = require("../helper/filterQuery.js");
const { successResponse } = require("../services/responseHandler.js");
const asyncHandler = require("express-async-handler");
const checkMongoId = require("../services/checkMongoId.js");

/**
 * @description get all subscriber data
 * @method GET
 * @route  /api/v1/subscriber
 * @access private
 */

 const allSubscriber = asyncHandler(async (req, res, next) => {
  const { queries, filters } = filterQuery(req);

  const result = await subscriberModel
    .find(filters)
    .skip(queries.skip)
    .limit(queries.limit)
    .sort(queries.sortBy);
  if (result.length < 1) {
    throw createError(400, "No subscriber data has founded");
  }
  // page , total count
  // count documents
  const count = await subscriberModel.countDocuments(filters);
  // page & limit
  const page = queries.page;
  const limit = queries.limit;

  // pagination
  const pagination = {
    totalDocuments: count,
    totalPages: Math.ceil(count / limit),
    currentPage: page,
    previousPage: page > 1 ? page - 1 : null,
    nextPage: page < Math.ceil(count / limit) ? page + 1 : null,
  };
  //response
  successResponse(res, {
    statusCode: 200,
    message: "All subscriber data",
    payload: {
      pagination,
      result,
    },
  });
});

/**
 * @description add  subscriber
 * @method POST
 * @route  /api/v1/subscriber
 * @access public
 */

 const addSubscriber = asyncHandler(async (req, res, next) => {
  const { email } = req.body;
  if (!email) throw createError(400, "Email is required!");

  // check subscriber
  const subscriber = await subscriberModel.exists({ email });
  if (subscriber) {
    throw createError(400, "You have already subscribe.");
  }

  // add subscriber
  const result = await subscriberModel.create(req.body);
 
  

  // response send
  successResponse(res, {
    statusCode: 201,
    message: "Successfully subscribed to KIN.",
    payload: {
      result,
    },
  });
});
/**
 * @description update  subscriber
 * @method POST
 * @route  /api/v1/subscriber
 * @access public
 */

 const updateSubscriberById = asyncHandler(async (req, res, next) => {
  // id validation check
  checkMongoId(req.params.id);

  // user check
  const subscriberData = await subscriberModel.findById(req.params.id);
  if (!subscriberData) throw createError(400, "No subscriber has founded");

  const subscriber = await subscriberModel.findByIdAndUpdate(
    req.params.id,
    {
      $set: {
        ...req.body,
      },
    },
    {
      new: true,
      runValidators: true,
    }
  );
  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Successfully updated",
    payload: {
      subscriber,
    },
  });
});

 const deleteSubscriberById = asyncHandler(async (req, res, next) => {
  // id validation check
  checkMongoId(req.params.id);

  // advisor check
  const subscriber = await subscriberModel.findById(req.params.id);

  if (!subscriber) throw createError(400, "No subscriber has founded");

  // data  delete from database
  const result = await subscriberModel.findByIdAndDelete(req.params.id);

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Successfully deleted",
    payload: {
      result,
    },
  });
});



module.exports = {
  allSubscriber,
  addSubscriber,
  updateSubscriberById,
  deleteSubscriberById,
};