const Ec = require("../model/ec.model.js");
const createError = require("http-errors");
const asyncHandler = require("express-async-handler");
const notExistData = require("../services/notExistData.js");
const checkMongoId = require("../services/checkMongoId.js");
const { successResponse } = require("../services/responseHandler.js");
const existData = require("../services/existData.js");
const userModel = require("../model/user.model.js");

/**
 *
 * @apiDescription    Get All Ec Data
 * @apiMethod         GET
 *
 * @apiRoute          /api/v1/ec
 * @apiAccess         Admin || SuperAdmin
 *
 * @apiSuccess        { success: true , message : Ec's Data Fetched Successfully , data: [] }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( unauthorized 401 )    Unauthorized, Only authenticated users can access the data
 * @apiError          ( Forbidden 403 )       Forbidden Only admins can access the data
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 *
 */

const getAllEc = asyncHandler(async (req, res) => {
  const ec = await Ec.find().sort({year:-1}).populate("members.user");

  if (!ec.length) {
    throw createError(404, "Couldn't find any data!");
  }

  successResponse(res, {
    statusCode: 200,
    message: "EC's Data Fetched Successfully",
    payload: {
      data: ec,
    },
  });
});

const ECFindById = asyncHandler(async (req, res) => {
  // id check
  checkMongoId(req.params.id);

  const data = await Ec.findById(req.params.id).populate("members.user");

  if (!data) {
    throw createError(404, "No Data found.");
  }

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Data fetched successfully",
    payload: {
      data: data,
    },
  });
});

const memberDataUpdateById = asyncHandler(async (req, res) => {
  // id check
  checkMongoId(req.params.id);

  // data find
  const data = await Ec.find({
    "members._id": req.params.id,
  });

  if (!data) {
    throw createError(404, "Couldn't find any data.");
  }

  let replaceData = {};
  Object.keys(req.body).forEach((key) => {
    key.replace(key, `members.$.${key}`);
    const replace = key.replace(key, `members.$.${key}`);
    replaceData = {
      ...replaceData,
      [replace]: req.body[key],
    };
  });

  // update options
  const options = {
    $set: {
      ...replaceData,
    },
  };

  // update

  const updatedData = await Ec.findOneAndUpdate(
    { "members._id": req.params.id },
    options,
    {
      new: true,
      runValidators: true,
    }
  ).populate("members.user");

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Member data updated",
    payload: {
      data: updatedData,
    },
  });
});

const removeMemberById = asyncHandler(async (req, res) => {
  // id check
  checkMongoId(req.params.id);

  await notExistData(
    Ec,
    { "members._id": req.params.id },
    "Couldn't find any data."
  );

  // remove options
  const options = {
    $pull: {
      members: {
        _id: req.params.id,
      },
    },
  };

  // find and update
  const data = await Ec.findOneAndUpdate(
    { "members._id": req.params.id },
    options,
    {
      new: true,
      runValidators: true,
    }
  ).populate("members.user");

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Member data deleted successfully",
    payload: {
      data,
    },
  });
});

/**
 *
 * @apiDescription    Add a new ec
 * @apiMethod         POST
 *
 * @apiRoute          /api/v1/ec
 * @apiAccess         Admin || SuperAdmin
 *
 * @apiBody           { name, year, member }
 *
 * @apiSuccess        { success: true , message: New ec added successfully, data: {} }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( unauthorized 401 )    Unauthorized, Only authenticated users can access the data
 * @apiError          ( Forbidden 403 )       Forbidden Only admins can access the data
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 *
 */

const addEc = asyncHandler(async (req, res) => {
  // existing data check
  await existData(Ec, { name: req.body.name }, "This name already exists");

  const ec = await Ec.create(req.body);

  if (!ec) {
    throw createError(400, "Couldn't add new ec.");
  }

  successResponse(res, {
    statusCode: 200,
    message: "New ec added successfully",
    payload: {
      data: ec,
    },
  });
});

/**
 *
 * @apiDescription    Update EC data
 * @apiMethod         PUT || PATCH
 *
 * @apiRoute          /api/v1/ec/:id
 * @apiAccess          Admin || SuperAdmin
 *
 * @apiParams         [ id = ObjectId ]
 * @apiBody           { any fields date }
 *
 * @apiSuccess        { success: true , message :  EC data is successfully updated, data: [] }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( unauthorized 401 )    Unauthorized, Only authenticated users can access the data
 * @apiError          ( Forbidden 403 )       Forbidden Only admins can access the data
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 *
 */

const updateEcById = asyncHandler(async (req, res) => {
  // id validation
  checkMongoId(req.params.id);

  // ec data check
  const ec = await Ec.findById(req.params.id);

  if (!ec) throw createError(404, "Couldn't find any data!");

  // update options
  const options = {
    $set: {
      ...req.body,
    },
  };

  // update ec
  const updatedEc = await Ec.findByIdAndUpdate(req.params.id, options, {
    new: true,
    runValidators: true,
    context: "query",
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Ec data is successfully updated.",
    payload: {
      data: updatedEc,
    },
  });
});

// add member in ec
const addMemberInEc = asyncHandler(async (req, res) => {
  // in check
  checkMongoId(req.params.id);

  // ec data check
  const ec = await Ec.findById(req.params.id);
  if (!ec) throw createError(404, "Couldn't find any data!");

  // member id check
  checkMongoId(req.body.user);

  // member data check
  const member = await userModel.findById(req.body.user);
  if (!member) throw createError(404, "Couldn't find any member!");

  // member already exist check
  const exist = ec.members.find((member) => member.user == req.body.user);
  if (exist) throw createError(400, "Member already exist!");

  // options
  const options = {
    $push: {
      members: {
        ...req.body,
      },
    },
  };

  // update data
  const updatedData = await Ec.findByIdAndUpdate(req.params.id, options, {
    new: true,
    runValidators: true,
    context: "query",
  });
  // response send
  successResponse(res, {
    statusCode: 200,
    message: "New member added successfully.",
    payload: {
      data: updatedData,
    },
  });
});

/**
 *
 * @apiDescription    Delete ec data
 * @apiMethod         DELETE
 *
 * @apiRoute          /api/v1/ec/:id
 * @apiAccess         Admin || SuperAdmin
 *
 * @apiParams         [ id = ObjectId ]
 *
 * @apiSuccess        { success: true , message :  Ec data is successfully deleted, data: [] }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( unauthorized 401 )    Unauthorized, Only authenticated users can access the data
 * @apiError          ( Forbidden 403 )       Forbidden Only admins can access the data
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 *
 */

const deleteEcById = asyncHandler(async (req, res) => {
  // id validation
  checkMongoId(req.params.id);

  // ec check
  const ec = await Ec.findById(req.params.id);

  if (!ec) throw createError(404, "Couldn't find any data!");

  // delete ec
  const deletedEc = await Ec.findByIdAndDelete(req.params.id);

  // response
  successResponse(res, {
    statusCode: 200,
    message: "Ec Data is successfully deleted.",
    payload: {
      data: deletedEc,
    },
  });
});

/**
 *
 * @apiDescription    Remove a member from ec
 * @apiMethod         PUT || PATCH
 *
 * @apiRoute          /api/v1/ec/:id/:memberIndex
 * @apiAccess          Admin || SuperAdmin
 *
 * @apiParams         [ id = ObjectId ]
 * @apiBody           { any fields date }
 *
 * @apiSuccess        { success: true , message :  EC data is successfully updated, data: [] }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( unauthorized 401 )    Unauthorized, Only authenticated users can access the data
 * @apiError          ( Forbidden 403 )       Forbidden Only admins can access the data
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 *
 */

const removeEcMemberById = asyncHandler(async (req, res) => {
  // id validation
  checkMongoId(req.params.id);

  // ec data check
  const ec = await Ec.findById(req.params.id);
  if (!ec) throw createError(404, "Couldn't find any ec data!");

  ec.members.find((member) => {
    if (member.id !== req.params.memberId) {
      throw createError(404, "Couldn't find any member!");
    }
  });

  // remove member
  const newData = ec.members.filter(
    (member) => member.id !== req.params.memberId
  );

  // update options
  const options = {
    $set: {
      members: newData,
    },
  };

  // update ec
  const updatedEc = await Ec.findByIdAndUpdate(req.params.id, options, {
    new: true,
    runValidators: true,
    context: "query",
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Ec data is successfully deleted.",
    payload: {
      data: updatedEc,
    },
  });
});

module.exports = {
  getAllEc,
  ECFindById,
  memberDataUpdateById,
  removeMemberById,
  addEc,
  updateEcById,
  addMemberInEc,
  deleteEcById,
  removeEcMemberById,
};
