const { unlinkSync } = require("fs");
const asyncHandler = require("express-async-handler");
const filterQuery = require("../helper/filterQuery.js");
const createError = require("http-errors");
const { successResponse } = require("../services/responseHandler.js");
const postModel = require("../model/post.model.js");
const checkImage = require("../services/imagesCheck.js");
const path = require("path");
const { log } = require("console");

/**
 * @description get all post  data
 * @method GET
 * @route  /api/v1/post
 * @access public
 */

const allPost = asyncHandler(async (req, res) => {
  const { queries, filters } = filterQuery(req);

  const post = await postModel
    .find(filters)
    .sort(queries.sortBy)
    .skip(queries.skip)
    .limit(queries.limit)
    .select(queries.fields);

  if (!post.length) {
    throw createError(400, "Couldn't find any data.");
  }

  //  count
  const count = await postModel.countDocuments(filters);

  // page & limit
  const page = queries.page;
  const limit = queries.limit;

  // pagination
  const pagination = {
    totalDocuments: count,
    totalPages: Math.ceil(count / limit),
    currentPage: page,
    previousPage: page > 1 ? page - 1 : null,
    nextPage: page < Math.ceil(count / limit) ? page + 1 : null,
  };

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "All post data",
    payload: {
      pagination,
      data: post,
    },
  });
});

/**
 * @description add new post  data
 * @method POST
 * @route  /api/v1/post
 * @access private
 */

const createPost = asyncHandler(async (req, res) => {
  const post = await postModel.create({
    ...req.body,
    post_photo: req?.file?.filename,
  });

  // response send
  successResponse(res, {
    statusCode: 201,
    message: "Successfully added a new post.",
    payload: {
      data: post,
    },
  });
});

/**
 * @description get single post  data
 * @method GET
 * @route  /api/v1/post/:slug
 * @access private
 */

const findPostBySlug = asyncHandler(async (req, res) => {
  const slug = req.params.slug;

  const post = await postModel.findOne().where("slug").equals(slug);

  // post slug validation check

  if (!post) throw createError(400, "Couldn't find any data.");

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Single post data",
    payload: {
      data: post,
    },
  });
});

/**
 * @description delete single post  data
 * @method DELETE
 * @route  /api/v1/post/:slug
 * @access private
 */

const deletePostBySlug = asyncHandler(async (req, res, next) => {
  const slug = req.params.slug;

  const post = await postModel.findOne({ slug });

  // post slug validation check
  if (!post) throw createError(400, "Couldn't find any data.");

  // find image in folder & delete
  checkImage("posts").find((image) => image === post?.post_photo) &&
    unlinkSync(path.resolve(`./public/images/posts/${post?.post_photo}`));
  const result = await postModel.findOneAndDelete({ slug });
  // response send

  successResponse(res, {
    statusCode: 200,
    message: "Successfully deleted a post.",
    payload: {
      data: result,
    },
  });
});

/**
 * @description update single post  data
 * @method PUT / PATCH
 * @route  /api/v1/post/:slug
 * @access private
 */

const updatePostById = asyncHandler(async (req, res, next) => {
  const post = await postModel.findById(req.params.id);
  // post slug validation check

  if (!post) throw createError(400, "Couldn't find any data.");
  const result = await postModel.findByIdAndUpdate(
    req.params.id,
    {
      $push: { comment: req?.body?.comment },
      $set: {
        slug: req?.body?.slug,
        title: req?.body?.title,
        post_photo: req?.file?.filename,
        date: req?.body?.date,
      },
    },
    { new: true }
  );

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Successfully updated a post.",
    payload: {
      data: result,
    },
  });
});

module.exports = {
  allPost,
  createPost,
  findPostBySlug,
  deletePostBySlug,
  updatePostById,
};
