const createError = require("http-errors");
const asyncHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const existData = require("../services/existData.js");
const randomHashCode = require("../helper/randomHashCode.js");
const {
  jwtLoginTokenExpire,
  jwtLoginTokenSecret,
  jwtSecret,
  passwordResetExpire,
  passwordResetKey,
  verifyKey,
  verifyKeyExpire,
} = require("../secret.js");
const User = require("../model/user.model.js");
const createJWT = require("../helper/createJWT.js");
const {
  errorResponse,
  successResponse,
} = require("../services/responseHandler.js");
const hideFromUser = require("../helper/hideFromUser.js");
const matchPassword = require("../helper/matchPassword.js");
const sendAccountVerifyMail = require("../utils/email/accountActivationMail.js");
const sendPasswordResetMail = require("../utils/email/passwordResetMail.js");


/**
 * @process  : field check ==> register ==> verify mail send to email
 */

/**
 *
 * @apiDescription    Create a new user account
 * @apiMethod         POST
 *
 * @apiRoute          /api/v1/auth/register
 * @apiAccess         public
 *
 * @apiBody           { name, email, password, gender }
 *
 * @apiSuccess        { success: true , message: active your account by verify email, data: {} }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( Not Found: 404 )      Couldn't find any data!
 * @apiError          ( Conflict: 409 )       Already have an account.
 *
 */
const userRegister = asyncHandler(async (req, res) => {
  const { email } = req.body;

  // check if user exist
  await existData(User, { email }, "Already have an account. Please login.");

  // random hash code
  const { code, hashCode } = randomHashCode(4);

  // create verify token
  const verifyToken = createJWT(
    { email, code: hashCode },
    verifyKey,
    verifyKeyExpire
  );

  // create user
  let user = await User.create(req.body);

  // prepare email data
  const emailData = {
    email,
    subject: "Account Activation Code.",
    code,
    verifyToken,
  };

  // send email
  sendAccountVerifyMail(emailData);

  // hide form user
  hideFromUser(user, [
    "role",
    "isBanned",
    "isEC",
    "isVerified",
    "trash",
    "createdAt",
    "updatedAt",
    "__v",
    "isEC",
    "approve",
  ]);

  // cookie set
  res.cookie("verifyToken", verifyToken, {
    httpOnly: false,
    maxAge: 1000 * 60 * 5, // 5 min
    secure: true, // only https
    sameSite: "none",
  });
  // response send
  successResponse(res, {
    statusCode: 201,
    message: `Email has been sent to ${email}. Follow the instruction to activate your account`,
    payload: {
      data: user,
    },
  });
});

/**
 * @process : mail ==> click ==> active account by url
 */

/**
 *
 * @apiDescription    Active user account
 * @apiMethod         POST
 *
 * @apiRoute          /api/v1/auth/activate
 * @apiAccess         registered user
 *
 * @apiBody           { email, password }
 *
 * @apiSuccess        { success: true , message: Successfully active account, data: {} }
 * @apiFailed         { success: false , error: { status, message }
 *
 */

const activeUserAccountByURL = asyncHandler(async (req, res) => {
  const token = req.params.token;
  // check token
  if (!token) {
    throw createError(400, "Invalid activation link");
  }

  // verify token
  jwt.verify(token, jwtSecret, async (err, decoded) => {
    if (err) {
      errorResponse(res, {
        statusCode: 400,
        message: "Expired Token",
      });
    }

    // check if user is already verified
    const user = await User.findOne({ email: decoded.email });

    if (user.isVerified === true) {
      errorResponse(res, {
        statusCode: 400,
        message: "Your account is already active. Please login.",
      });
    }

    // update user
    await User.findOneAndUpdate(
      { email: decoded?.email },
      { isVerified: true },
      { new: true }
    );

    // response send
    successResponse(res, {
      statusCode: 201,
      message: "Successfully activated your account.",
    });
  });
});

/**
 * @process : mail ==> give code ==> active account by code
 */
const activeUserAccountByCode = asyncHandler(async (req, res) => {
  const token = req.cookies.verifyToken;

  // check token
  if (!token) {
    throw createError(400, "Token not found");
  }

  // verify token
  jwt.verify(token, jwtSecret, async (err, decoded) => {
    if (err) {
      return errorResponse(res, {
        statusCode: 400,
        message: "Time expired! ",
      });
    }

    // check if user is already verified
    const user = await User.findOne({ email: decoded?.email });

    // user exist check
    if (!user) {
      return errorResponse(res, {
        statusCode: 400,
        message: "Couldn't find any user account!. Please register.",
      });
    }

    if (user.isVerified === true) {
      return errorResponse(res, {
        statusCode: 400,
        message: "Your account is already active. Please login.",
      });
    }

    // check code
    const code = bcrypt.compareSync(req.body.code, decoded.code);

    if (!code) {
      return errorResponse(res, {
        statusCode: 400,
        message: "wrong code",
      });
    } else {
      await User.findOneAndUpdate(
        { email: decoded?.email },
        { isVerified: true },
        { new: true }
      );

      // cookie clear
      res?.clearCookie("verifyToken", {
        sameSite: "strict",
      });

      // response send
      return successResponse(res, {
        statusCode: 201,
        message: "Successfully activated your account.",
      });
    }
  });
});

/**
 * @process : time expire or another ==> email check ==> resend verify token
 */
/**
 *
 * @apiDescription    User login
 * @apiMethod         POST
 *
 * @apiRoute          /api/v1/auth/login
 * @apiAccess         public
 *
 * @apiBody           { email, password }
 *
 * @apiDenied         { isBanned: true }
 *
 * @apiSuccess        { success: true , message: Successfully Login, data: {} }
 * @apiFailed         { success: false , error: { status, message }
 *
 * @apiError          ( Bad Request 400 )     Invalid syntax / parameters
 * @apiError          ( Not Found: 404 )      Couldn't find any user account!. Please register.
 *
 */

// resend activation code
const resendActivationCode = asyncHandler(async (req, res) => {
  const { email } = req.body;

  const user = await User.findOne({ email });

  // check: user is exist or not.
  if (!user) {
    throw createError(400, "Couldn't find any user account!. Please register.");
  }

  // check: user is activate or not
  if (user.isVerified === true) {
    throw createError(400, "Your account is already active. Please login.");
  }

  // random hash code
  const { code, hashCode } = randomHashCode(4);

  // create verify token
  const verifyToken = createJWT(
    { email, code: hashCode },
    verifyKey,
    verifyKeyExpire
  );

  // prepare email data
  const emailData = {
    email,
    subject: "Account Activation Code",
    code,
    verifyToken,
  };

  // send email
  sendAccountVerifyMail(emailData);

  res.cookie("verifyToken", verifyToken, {
    httpOnly: true,
    maxAge: 1000 * 60 * 5, // 5 min
    secure: true, // only https
    sameSite: "none",
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: `Email has been sent to ${email}. Follow the instruction to activate your account`,
  });
});

/**
 * @process : fields check ==> login ==> access token set to cookies
 */
const userLogin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // get user
  const user = await User.findOne({ email });

  // user check
  if (!user)
    throw createError(400, "Couldn't find any user account!. Please register.");

  //  password match
  matchPassword(password, user.password);

  // isActivate check
  if (user.isVerified === false) {
    throw createError(400, "Please active your account.");
  }

  // isBanned check
  if (user.isBanned === true) {
    throw createError(400, "You are banned. Please contact with authority");
  }

  // create  access token
  const accessToken = createJWT(
    { email },
    jwtLoginTokenSecret,
    jwtLoginTokenExpire
  );

  // response send
  res.cookie("accessToken", accessToken, {
    httpOnly: false,
    maxAge: 1000 * 60 * 60 * 24 * 15, // 15 days
    secure: true, // only https
    sameSite: "none",
  });

  successResponse(res, {
    statusCode: 200,
    message: "Successfully Login to KIN.",
    payload: {
      data: user,
    },
  });
});

const dashboardLogin = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // get user
  const user = await User.findOne({ email });

  // user check
  if (!user)
    throw createError(400, "Couldn't find any user account!.");

   if(user.role !== "admin" && user.role !== "superAdmin")  throw createError(400, "Please contact with authority.");

  //  password match
  matchPassword(password, user.password);

  // isActivate check
  if (user.isVerified === false) {
    throw createError(400, "Please active your account.");
  }

  // isBanned check
  if (user.isBanned === true) {
    throw createError(400, "You are banned. Please contact with authority");
  }

  // create  access token
  const accessToken = createJWT(
    { email },
    jwtLoginTokenSecret,
    jwtLoginTokenExpire
  );

  // response send
  res.cookie("accessToken", accessToken, {
    httpOnly: false,
    maxAge: 1000 * 60 * 60 * 24 * 15, // 15 days
    secure: true, // only https
    sameSite: "none",
  });

  successResponse(res, {
    statusCode: 200,
    message: "Successfully Login to KIN.",
    payload: {
      data: user,
    },
  });
});


/**
 *
 * @apiDescription    User Logout
 * @apiMethod         POST
 *
 * @apiRoute          /api/v1/auth/logout
 * @apiAccess         Only Logged in user
 *
 * @apiCookie         accessToken
 *
 * @apiSuccess        { success: true , message: Successfully Logout }
 * @apiFailed         { success: false , error: { status, message }
 *
 */
const userLogout = (req, res) => {
  res?.clearCookie("accessToken", {
    httpOnly: false,
    secure: true, // only https
    sameSite: "none",
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Successfully Logout.",
  });
};

// find account
const findAccount = asyncHandler(async (req, res) => {
  const { email } = req.body;

  // user find
  const user = await User.findOne({ email });
  if (!user) {
    throw createError(400, "User account not found");
  }

  // response

  successResponse(res, {
    statusCode: 200,
    message: "User Found",
    Data: {
      email: user.email,
    },
  });
});

// password reset request
const passwordResetRequest = asyncHandler(async (req, res) => {
  const { email } = req.body;

  // code generate
  const { code, hashCode } = randomHashCode(4);

  // create token
  const resetToken = createJWT(
    { email, code: hashCode },
    passwordResetKey,
    passwordResetExpire
  );

  // prepare email data
  const emailData = {
    email,
    subject: "Password Reset Code",
    code,
    resetToken,
  };

  // send email
  sendPasswordResetMail(emailData);

  // response
  res.cookie("resetToken", resetToken, {
    httpOnly: true,
    maxAge: 5 * 60 * 1000, // 5 minutes
    sameSite: "strict",
  });

  // response send
  successResponse(res, {
    statusCode: 200,
    message: "Code sent to your email.",
    payload: {
      email: email,
      code,
    },
  });
});

// find account by email and password reset

/**
 * @param {email}
 * @body {password}
 * @cookie {verifyToken}
 */
const passwordReset = asyncHandler(async (req, res) => {
  const { password, code, email } = req.body;
  const { resetToken } = req.cookies;

  // user find
  if (!password) {
    throw createError(400, "Please provide password");
  }

  if (!code) {
    throw createError(400, "Please provide code");
  }

  if (!resetToken) {
    throw createError(400, "Invalid request");
  }

  jwt.verify(resetToken, passwordResetKey, async (err, decode) => {
    if (err) {
      return res.status(401).json({
        status: "Failed",
        message: "Code Expired!",
      });
    }

    // check code
    const isMatch = await bcrypt.compare(code, decode.code);
    if (!isMatch) {
      return errorResponse(res, {
        statusCode: 400,
        message: "Wrong Code",
      });
    }

    // update user
    const updateUser = await User.findOneAndUpdate(
      { email },
      {
        $set: {
          password,
        },
      },
      { new: true }
    );

    // response

    res.clearCookie("resetToken", {
      sameSite: "strict",
    });

    successResponse(res, {
      statusCode: 200,
      message: "Successfully password updated.",
      payload: {
        data: updateUser,
      },
    });
  });
});

// me route
const me = asyncHandler(async (req, res) => {
  console.log("tr");
  if (!req?.me) {
    throw createError(404, "User not found");
  }
  successResponse(res, {
    statusCode: 200,
    message: "Login User Data.",
    payload: {
      data: req.me,
    },
  });
});

module.exports = {
  userRegister,
  activeUserAccountByURL,
  activeUserAccountByCode,
  resendActivationCode,
  userLogin,
  userLogout,
  findAccount,
  passwordResetRequest,
  passwordReset,
  dashboardLogin,
  me,
};
