const mongoose = require("mongoose");

// create newsTicker schema

const newsSchema = mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please enter news title"],
  },
  fb_url: {
    type: String,
    required: [true, "Please enter fb url"],
  },
});

// export newsTicker

module.exports = mongoose.model("News", newsSchema);
