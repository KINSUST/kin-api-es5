
const mongoose = require("mongoose");
//create schema

const programSchema = mongoose.Schema(
  {
    program_photo: {
      type: String,
      required: [true, "Please upload a photo"],
    },
    fb_url: {
      type: String,
      required: [true, "Please provide a facebook url"],
    },
    title: {
      type: String,
      required: [true, "Please provide a title"],
    },
    date: {
      type: String,
      required: [true, "Please provide a date"],
    },
    time: {
      type: String,
      required: [true, "Please provide a time"],
    },
    venue: {
      type: String,
      required: [true, "Please provide a venue"],
    },
  },
  {
    timestamps: true,
  }
);

// create users collecting(auto plural)
module.exports = mongoose.model("Program", programSchema);